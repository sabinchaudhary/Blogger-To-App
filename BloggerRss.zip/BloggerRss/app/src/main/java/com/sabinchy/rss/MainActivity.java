package com.sabinchy.rss;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.AdapterView;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class MainActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	private DrawerLayout _drawer;
	
	private LinearLayout linear2;
	private ListView listview1;
	private LinearLayout _drawer_linear4;
	private LinearLayout _drawer_linear5;
	private LinearLayout _drawer_linear6;
	private LinearLayout _drawer_linear7;
	private LinearLayout _drawer_linear8;
	private Button _drawer_button1;
	private LinearLayout _drawer_linear9;
	private LinearLayout _drawer_linear10;
	
	private Intent hdhs = new Intent();
	private SharedPreferences kat;
	
	private AlertDialog.Builder dia;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = (DrawerLayout) findViewById(R.id._drawer);ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(MainActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.setDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		listview1 = (ListView) findViewById(R.id.listview1);
		_drawer_linear4 = (LinearLayout) _nav_view.findViewById(R.id.linear4);
		_drawer_linear5 = (LinearLayout) _nav_view.findViewById(R.id.linear5);
		_drawer_linear6 = (LinearLayout) _nav_view.findViewById(R.id.linear6);
		_drawer_linear7 = (LinearLayout) _nav_view.findViewById(R.id.linear7);
		_drawer_linear8 = (LinearLayout) _nav_view.findViewById(R.id.linear8);
		_drawer_button1 = (Button) _nav_view.findViewById(R.id.button1);
		_drawer_linear9 = (LinearLayout) _nav_view.findViewById(R.id.linear9);
		_drawer_linear10 = (LinearLayout) _nav_view.findViewById(R.id.linear10);
		kat = getSharedPreferences("kat", Activity.MODE_PRIVATE);
		
		dia = new AlertDialog.Builder(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				hdhs.putExtra("data", ((CustomAdapter) listview1.getAdapter()).getDataHolder().get((int)_position).toString());
				hdhs.setClass(getApplicationContext(), DevamActivity.class);
				startActivity(hdhs);
			}
		});
		
		
		};

	
	private void initializeLogic() {
		dia.setTitle("Welcome");
		dia.setMessage("This app was developed by Sabin Chaudhary\n\nSource Web site: www.udakuspecially.com");
		dia.setPositiveButton("Close", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		dia.create().show();
		_setDrawerWidth(250);
		
		final String urlString = "https://www.udakuspecially.com/rss.xml";
		Parser parser = new Parser();
		parser.execute(urlString);
		parser.onFinish(new Parser.OnTaskCompleted() {
				@Override
				public void onTaskCompleted(ArrayList<Article> list) {
						CustomAdapter mAdapter = new CustomAdapter(list, MainActivity.this);
				        listview1.setAdapter(mAdapter);
				}
				@Override
				public void onError() {
						runOnUiThread(new Runnable() {
								@Override
								public void run() {
										Toast.makeText(MainActivity.this, "Unable to load data.", Toast.LENGTH_LONG).show();
								}
						});
				}
		});
	}
	public class CustomAdapter extends ArrayAdapter<Article>{
		    private ArrayList<Article> articles;
		    Context mContext;
		    private class ViewHolder {
			        TextView name;
			        TextView yazar;
			         ImageView image;
			    }
		    public CustomAdapter(ArrayList<Article> list, Context context) {
			        super(context, R.layout.row_item, list);
			        this.articles = list;
			        this.mContext=context;
			    }
		
		public ArrayList<Article> getDataHolder() {
			
			return articles;
			
		}
		
		    @Override
		    public View getView(int position, View convertView, ViewGroup parent) {
			    	Article currentArticle = articles.get(position);
			        //DataModel dataModel = getItem(position);
			        ViewHolder viewHolder;
			        final View result;
			        if (convertView == null) {
				            viewHolder = new ViewHolder();
				            LayoutInflater inflater = LayoutInflater.from(getContext());
				            convertView = inflater.inflate(R.layout.row_item, parent, false);
				            viewHolder.name = (TextView) convertView.findViewById(R.id.name);
				
				viewHolder.yazar = (TextView) convertView.findViewById(R.id.yazar);
				
				viewHolder.image = (ImageView) convertView.findViewById(R.id.img);
				
				            result=convertView;
				            convertView.setTag(viewHolder);
				        } else {
				            viewHolder = (ViewHolder) convertView.getTag();
				            result=convertView;
				        }
			        viewHolder.name.setText(currentArticle.getTitle());
			
			viewHolder.yazar.setText(currentArticle.getAuthor());
			
			_setImageFromUrl(viewHolder.image, currentArticle.getImage());
			
			        return convertView;
			    }
	}{
		
	}
	public static class XMLParser extends Observable {
		    private ArrayList<Article> articles;
		    private Article currentArticle;
		    public XMLParser() {
			        articles = new ArrayList<>();
			        currentArticle = new Article();
			    }
		    public void parseXML(String xml) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
			        org.xmlpull.v1.XmlPullParserFactory factory = org.xmlpull.v1.XmlPullParserFactory.newInstance();
			        factory.setNamespaceAware(false);
			        org.xmlpull.v1.XmlPullParser xmlPullParser = factory.newPullParser();
			        xmlPullParser.setInput(new java.io.StringReader(xml));
			        boolean insideItem = false;
			        int eventType = xmlPullParser.getEventType();
			        while (eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
				            if (eventType == org.xmlpull.v1.XmlPullParser.START_TAG) {
					                if (xmlPullParser.getName().equalsIgnoreCase("item")) {
						                    insideItem = true;
						                } else if (xmlPullParser.getName().equalsIgnoreCase("title")) {
						                    if (insideItem) {
							                        String title = xmlPullParser.nextText();
							                        currentArticle.setTitle(title);
							                    }
						                } else if (xmlPullParser.getName().equalsIgnoreCase("link")) {
						                    if (insideItem) {
							                        String link = xmlPullParser.nextText();
							                        currentArticle.setLink(link);
							                    }
						                } else if (xmlPullParser.getName().equalsIgnoreCase("dc:creator")) {
						                    if (insideItem) {
							                        String author = xmlPullParser.nextText();
							                        currentArticle.setAuthor(author);
							                    }
						                } else if (xmlPullParser.getName().equalsIgnoreCase("category")) {
						                    if (insideItem) {
							                        String category = xmlPullParser.nextText();
							                        currentArticle.addCategory(category);
							                    }
						                } else if (xmlPullParser.getName().equalsIgnoreCase("media:thumbnail")) {
						                    if (insideItem) {
							                        String img = xmlPullParser.getAttributeValue(null, "url");
							                        currentArticle.setImage(img);
							                    }
						                } else if (xmlPullParser.getName().equalsIgnoreCase("description")) {
						                    if (insideItem) {
							                        String description = xmlPullParser.nextText();
							                        if (currentArticle.getImage() == null) {
								                            currentArticle.setImage(getImageUrl(description));
								                        }
							                        currentArticle.setDescription(description);
							                    }
						                } else if (xmlPullParser.getName().equalsIgnoreCase("content:encoded")) {
						                    if (insideItem) {
							                        String content = xmlPullParser.nextText();
							                        if (currentArticle.getImage() == null) {
								                            currentArticle.setImage(getImageUrl(content));
								                        }
							                        currentArticle.setContent(content);
							                    }
						                } else if (xmlPullParser.getName().equalsIgnoreCase("pubDate")) {
						                    Date pubDate = new Date(xmlPullParser.nextText());
						                    currentArticle.setPubDate(pubDate);
						                }
					            } else if (eventType == org.xmlpull.v1.XmlPullParser.END_TAG && xmlPullParser.getName().equalsIgnoreCase("item")) {
					                insideItem = false;
					                articles.add(currentArticle);
					                currentArticle = new Article();
					            }
				            eventType = xmlPullParser.next();
				        }
			        triggerObserver();
			    }
		    private void triggerObserver() {
			        setChanged();
			        notifyObservers(articles);
			    }
		    private String getImageUrl(String input) {
			        String url = null;
			        java.util.regex.Pattern patternImg = java.util.regex.Pattern.compile("(<img .*?>)");
			        java.util.regex.Matcher matcherImg = patternImg.matcher(input);
			        if (matcherImg.find()) {
				            String imgTag = matcherImg.group(1);
				            java.util.regex.Pattern patternLink = java.util.regex.Pattern.compile("src\\s*=\\s*\"(.+?)\"");
				            java.util.regex.Matcher matcherLink = patternLink.matcher(imgTag);
				            if (matcherLink.find()) {
					                url = matcherLink.group(1);
					            }
				        }
			        return url;
			    }
	}
	
	
	public static class Parser extends AsyncTask<String, Void, String> implements Observer {
		    private XMLParser xmlParser;
		    private static ArrayList<Article> articles = new ArrayList<>();
		    private OnTaskCompleted onComplete;
		    public Parser() {
			        xmlParser = new XMLParser();
			        xmlParser.addObserver(this);
			    }
		    public interface OnTaskCompleted {
			        void onTaskCompleted(ArrayList<Article> list);
			        void onError();
			    }
		    public void onFinish(OnTaskCompleted onComplete) {
			        this.onComplete = onComplete;
			    }
		    @Override
		    protected String doInBackground(String... ulr) {
			        okhttp3.Response response = null;
			        okhttp3.OkHttpClient client = new okhttp3.OkHttpClient();
			        okhttp3.Request request = new okhttp3.Request.Builder()
			                .url(ulr[0])
			                .build();
			        try {
				            response = client.newCall(request).execute();
				            if (response.isSuccessful())
				                return response.body().string();
				        } catch (java.io.IOException e) {
				            e.printStackTrace();
				            onComplete.onError();
				        }
			        return null;
			    }
		    @Override
		    protected void onPostExecute(String result) {
			        if (result != null) {
				            try {
					                xmlParser.parseXML(result);
					                Log.i("RSS Parser ", "RSS parsed correctly!");
					            } catch (Exception e) {
					                e.printStackTrace();
					                onComplete.onError();
					            }
				        } else
			            onComplete.onError();
			    }
		    @Override
		    @SuppressWarnings("unchecked")
		    public void update(Observable observable, Object data) {
			        articles = (ArrayList<Article>) data;
			        onComplete.onTaskCompleted(articles);
			    }
	}
	
	
	public static class Article {
		    private String title;
		    private String author;
		    private String link;
		    private Date pubDate;
		    private String description;
		    private String content;
		    private String image;
		    private List<String> categories;
		    public String getTitle() {
			        return title;
			    }
		    public String getAuthor() {
			        return author;
			    }
		    public String getLink() {
			        return link;
			    }
		    public Date getPubDate() {
			        return pubDate;
			    }
		    public String getDescription() {
			        return description;
			    }
		    public String getContent() {
			        return content;
			    }
		    public String getImage() {
			        return image;
			    }
		    public void setTitle(String title) {
			        this.title = title;
			    }
		    public void setAuthor(String author) {
			        this.author = author;
			    }
		    public void setLink(String link) {
			        this.link = link;
			    }
		    public void setPubDate(Date pubDate) {
			        this.pubDate = pubDate;
			    }
		    public void setDescription(String description) {
			        this.description = description;
			    }
		    public void setContent(String content) {
			        this.content = content;
			    }
		    public void setImage(String image) {
			        this.image = image;
			    }
		    public List<String> getCategories() {
			        return categories;
			    }
		    public void addCategory(String category) {
			        if (categories == null)
			            categories = new ArrayList<>();
			        categories.add(category);
			    }
		    @Override
		    public String toString() {
			
			
			HashMap<String, Object> map = new HashMap<>();
			
			map.put("title", title);
			map.put("author", author);
			map.put("link", link);
			map.put("pubDate", pubDate);
			map.put("description", description);
			map.put("content", content);
			map.put("image", image);
			map.put("categories", categories);
			
			return new Gson().toJson(map);
			
			    }
	}
	{
		
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			super.onBackPressed();
		}
	}
	private void _setImageFromUrl (final ImageView _ig, final String _url) {
		Glide.with(getApplicationContext()).load(Uri.parse(_url)).into(_ig);
	}
	
	
	private void _setDrawerWidth (final double _num) {
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		android.support.v4.widget.DrawerLayout.LayoutParams params = (android.support.v4.widget.DrawerLayout.LayoutParams)_nav_view.getLayoutParams();
		
		params.width = (int)getDip((int)_num);
		
		params.height = android.support.v4.widget.DrawerLayout.LayoutParams.MATCH_PARENT;
		
		_nav_view.setLayoutParams(params);
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.row_item, null);
			}
			
			final TextView yazar = (TextView) _v.findViewById(R.id.yazar);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final LinearLayout linear2 = (LinearLayout) _v.findViewById(R.id.linear2);
			final ImageView img = (ImageView) _v.findViewById(R.id.img);
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final TextView name = (TextView) _v.findViewById(R.id.name);
			
			
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
